"""Inference backends for local and OpenAI-compatible models."""

from __future__ import annotations

import importlib.util
import json
import os
import time
import urllib.error
import urllib.request
from abc import ABC, abstractmethod
from pathlib import Path
from typing import Any, Protocol, Sequence

from .config import InferenceConfig, ModelConfig, RetryConfig
from .records import Generation, Message


class BackendError(RuntimeError):
    """A provider or local inference failure."""


class BackendTimeout(TimeoutError):
    """Inference exceeded the configured request timeout."""


class TokenizerAdapter(Protocol):
    @property
    def identity(self) -> str: ...

    def encode(self, text: str, *, add_special_tokens: bool = False) -> list[int]: ...

    def format_chat(self, messages: Sequence[Message]) -> str: ...


class InferenceBackend(ABC):
    def __init__(self, model: ModelConfig, inference: InferenceConfig, retry: RetryConfig) -> None:
        self.model = model
        self.inference = inference
        self.retry = retry

    @abstractmethod
    def generate(self, messages: Sequence[Message]) -> Generation:
        raise NotImplementedError

    @abstractmethod
    def tokenizer(self) -> TokenizerAdapter:
        raise NotImplementedError

    def close(self) -> None:
        """Release resources held by a backend."""


class HuggingFaceTokenizerAdapter:
    def __init__(
        self,
        tokenizer: Any,
        identity: str,
        chat_template_kwargs: dict[str, Any] | None = None,
    ) -> None:
        self._tokenizer = tokenizer
        self._identity = identity
        self._chat_template_kwargs = chat_template_kwargs or {}

    @property
    def identity(self) -> str:
        return self._identity

    def encode(self, text: str, *, add_special_tokens: bool = False) -> list[int]:
        return list(self._tokenizer.encode(text, add_special_tokens=add_special_tokens))

    def format_chat(self, messages: Sequence[Message]) -> str:
        values = [message.to_dict() for message in messages]
        if getattr(self._tokenizer, "chat_template", None):
            return self._tokenizer.apply_chat_template(
                values,
                tokenize=False,
                add_generation_prompt=True,
                **self._chat_template_kwargs,
            )
        return "\n\n".join(f"{message.role.upper()}: {message.content}" for message in messages) + "\n\nASSISTANT:"


def load_huggingface_tokenizer(model: ModelConfig) -> HuggingFaceTokenizerAdapter:
    try:
        from transformers import AutoTokenizer
    except ImportError as error:  # pragma: no cover - optional inference dependency
        raise BackendError("transformers is required to load a local tokenizer") from error
    tokenizer = AutoTokenizer.from_pretrained(
        model.resolved_tokenizer_id,
        revision=model.revision,
        trust_remote_code=model.trust_remote_code,
        local_files_only=model.local_files_only,
    )
    if tokenizer.pad_token_id is None and tokenizer.eos_token_id is not None:
        tokenizer.pad_token_id = tokenizer.eos_token_id
    chat_template_file = model.extra.get("chat_template_file")
    if chat_template_file is not None:
        if (
            not isinstance(chat_template_file, str)
            or Path(chat_template_file).name != chat_template_file
        ):
            raise BackendError(
                f"model {model.name}: extra.chat_template_file must be a filename"
            )
        if not model.local_files_only:
            raise BackendError(
                f"model {model.name}: extra.chat_template_file requires local_files_only"
            )
        template_path = Path(_local_snapshot_path(model)) / chat_template_file
        try:
            tokenizer.chat_template = template_path.read_text(encoding="utf-8")
        except OSError as error:
            raise BackendError(
                f"model {model.name}: could not read chat template {template_path}"
            ) from error
    chat_template_kwargs = model.extra.get("chat_template", {})
    if not isinstance(chat_template_kwargs, dict):
        raise BackendError(f"model {model.name}: extra.chat_template must be an object")
    return HuggingFaceTokenizerAdapter(
        tokenizer,
        model.resolved_tokenizer_id,
        chat_template_kwargs,
    )


class TransformersBackend(InferenceBackend):
    def __init__(self, model: ModelConfig, inference: InferenceConfig, retry: RetryConfig) -> None:
        super().__init__(model, inference, retry)
        try:
            import torch
            from transformers import AutoModelForCausalLM
        except ImportError as error:  # pragma: no cover - optional inference dependency
            raise BackendError("the transformers backend requires torch and transformers") from error

        self._torch = torch
        self._tokenizer_adapter = load_huggingface_tokenizer(model)
        tokenizer = self._tokenizer_adapter._tokenizer
        load_arguments: dict[str, Any] = {
            "revision": model.revision,
            "trust_remote_code": model.trust_remote_code,
            "local_files_only": model.local_files_only,
            "device_map": "auto",
        }
        if model.dtype != "auto":
            dtype = getattr(torch, model.dtype, None)
            if dtype is None:
                raise BackendError(f"unknown torch dtype {model.dtype!r}")
            load_arguments["torch_dtype"] = dtype
        self._model = AutoModelForCausalLM.from_pretrained(model.resolved_model_id, **load_arguments)
        self._model.eval()
        self._tokenizer = tokenizer

    def tokenizer(self) -> TokenizerAdapter:
        return self._tokenizer_adapter

    def generate(self, messages: Sequence[Message]) -> Generation:
        started = time.monotonic()
        prompt = self._tokenizer_adapter.format_chat(messages)
        inputs = self._tokenizer(prompt, return_tensors="pt")
        device = next(self._model.parameters()).device
        inputs = {name: value.to(device) for name, value in inputs.items()}
        do_sample = self.inference.temperature > 0
        arguments: dict[str, Any] = {
            **inputs,
            "max_new_tokens": self.inference.max_new_tokens,
            "do_sample": do_sample,
            "pad_token_id": self._tokenizer.pad_token_id,
        }
        if do_sample:
            arguments["temperature"] = self.inference.temperature
            arguments["top_p"] = self.inference.top_p
            generator = self._torch.Generator(device=device)
            generator.manual_seed(self.inference.seed)
            arguments["generator"] = generator
        with self._torch.inference_mode():
            output = self._model.generate(**arguments)
        prompt_length = inputs["input_ids"].shape[-1]
        generated = output[0, prompt_length:]
        raw_text = self._tokenizer.decode(generated, skip_special_tokens=True)
        text = final_answer_text(raw_text, self.model)
        return Generation(
            text=text,
            finish_reason="length" if generated.shape[-1] >= self.inference.max_new_tokens else "stop",
            prompt_tokens=prompt_length,
            completion_tokens=generated.shape[-1],
            latency_seconds=time.monotonic() - started,
            raw_text=raw_text if text != raw_text else None,
            provider_metadata={"backend": "transformers"},
        )


class VLLMBackend(InferenceBackend):
    def __init__(self, model: ModelConfig, inference: InferenceConfig, retry: RetryConfig) -> None:
        super().__init__(model, inference, retry)
        try:
            from vllm import LLM
        except ImportError as error:  # pragma: no cover - optional inference dependency
            raise BackendError(f"vLLM could not be imported: {error}") from error
        self._tokenizer_adapter = load_huggingface_tokenizer(model)
        model_location = _local_snapshot_path(model) if model.local_files_only else model.resolved_model_id
        tokenizer_location = (
            model_location
            if model.resolved_tokenizer_id == model.resolved_model_id
            else model.resolved_tokenizer_id
        )
        arguments: dict[str, Any] = {
            "model": model_location,
            "tokenizer": tokenizer_location,
            "dtype": model.dtype,
            "tensor_parallel_size": model.tensor_parallel_size,
            "trust_remote_code": model.trust_remote_code,
        }
        if model.revision and model_location == model.resolved_model_id:
            arguments["revision"] = model.revision
        arguments.update(vllm_runtime_options(model))
        self._llm = LLM(**arguments)

    def tokenizer(self) -> TokenizerAdapter:
        return self._tokenizer_adapter

    def generate(self, messages: Sequence[Message]) -> Generation:
        try:
            from vllm import SamplingParams
            from vllm.sampling_params import StructuredOutputsParams
        except ImportError as error:  # pragma: no cover
            raise BackendError(f"vLLM could not be imported: {error}") from error
        started = time.monotonic()
        prompt = self._tokenizer_adapter.format_chat(messages)
        sampling = vllm_sampling_options(self.model, self.inference)
        structured_regex = self.model.extra.get("structured_regex")
        if structured_regex is not None:
            if not isinstance(structured_regex, str) or not structured_regex:
                raise BackendError(
                    f"model {self.model.name}: extra.structured_regex must be a non-empty string"
                )
            sampling["structured_outputs"] = StructuredOutputsParams(regex=structured_regex)
        result = self._llm.generate(
            [prompt], SamplingParams(**_phase_sampling(sampling, self.model, "reasoning")), use_tqdm=False
        )[0]
        candidate = result.outputs[0]
        prompt_token_ids = getattr(result, "prompt_token_ids", None)
        completion_token_ids = getattr(candidate, "token_ids", None)
        raw_text = candidate.text
        text = final_answer_text(raw_text, self.model)
        total_prompt_tokens = len(prompt_token_ids) if prompt_token_ids is not None else None
        total_completion_tokens = (
            len(completion_token_ids) if completion_token_ids is not None else None
        )
        phases = 1

        bounded = bounded_final_options(self.model, self.inference)
        needs_final_phase = bounded is not None and (
            bounded["mode"] == "followup" or not text
        )
        if needs_final_phase:
            if bounded["mode"] == "close_think":
                final_prompt = prompt + raw_text + "\n" + reasoning_closing_tag(self.model) + "\n\n"
            else:
                followup = tuple(messages) + (
                    Message("assistant", raw_text),
                    Message(
                        "user",
                        "Stop reasoning now. Return only the final answer as exactly 9 lines "
                        "of 9 space-separated symbols.",
                    ),
                )
                final_prompt = self._tokenizer_adapter.format_chat(followup)
            final_sampling = _phase_sampling(sampling, self.model, "final")
            final_structured_regex = self.model.extra.get("final_structured_regex")
            if final_structured_regex is not None:
                if not isinstance(final_structured_regex, str) or not final_structured_regex:
                    raise BackendError(
                        f"model {self.model.name}: extra.final_structured_regex must be "
                        "a non-empty string"
                    )
                final_sampling["structured_outputs"] = StructuredOutputsParams(
                    regex=final_structured_regex
                )
            final_result = self._llm.generate(
                [final_prompt],
                SamplingParams(**final_sampling),
                use_tqdm=False,
            )[0]
            final_candidate = final_result.outputs[0]
            final_prompt_ids = getattr(final_result, "prompt_token_ids", None)
            final_completion_ids = getattr(final_candidate, "token_ids", None)
            text = final_candidate.text.strip()
            raw_text = raw_text + "\n\n[FINAL PHASE]\n" + final_candidate.text
            candidate = final_candidate
            if total_prompt_tokens is not None and final_prompt_ids is not None:
                total_prompt_tokens += len(final_prompt_ids)
            else:
                total_prompt_tokens = None
            if total_completion_tokens is not None and final_completion_ids is not None:
                total_completion_tokens += len(final_completion_ids)
            else:
                total_completion_tokens = None
            phases = 2
        return Generation(
            text=text,
            finish_reason=str(getattr(candidate, "finish_reason", "stop")),
            prompt_tokens=total_prompt_tokens,
            completion_tokens=total_completion_tokens,
            latency_seconds=time.monotonic() - started,
            raw_text=raw_text if text != raw_text else None,
            provider_metadata={"backend": "vllm", "generation_phases": phases},
        )


class OpenAICompatibleBackend(InferenceBackend):
    def __init__(self, model: ModelConfig, inference: InferenceConfig, retry: RetryConfig) -> None:
        super().__init__(model, inference, retry)
        self._tokenizer_adapter: TokenizerAdapter | None = None
        if model.tokenizer_id:
            self._tokenizer_adapter = load_huggingface_tokenizer(model)

    def tokenizer(self) -> TokenizerAdapter:
        if self._tokenizer_adapter is None:
            raise BackendError(
                f"model {self.model.name} requires tokenizer_id for local token diagnostics"
            )
        return self._tokenizer_adapter

    def generate(self, messages: Sequence[Message]) -> Generation:
        assert self.model.api_base is not None
        url = self.model.api_base.rstrip("/") + "/chat/completions"
        payload = {
            "model": self.model.model_id,
            "messages": [message.to_dict() for message in messages],
            "max_completion_tokens": self.inference.max_new_tokens,
            "temperature": self.inference.temperature,
            "top_p": self.inference.top_p,
            "seed": self.inference.seed,
        }
        for parameter in self.model.extra.get("omit_parameters", []):
            payload.pop(parameter, None)
        payload.update(self.model.extra.get("request", {}))
        headers = {"Content-Type": "application/json", "X-OpenRouter-Metadata": "enabled"}
        headers.update(self.model.extra.get("headers", {}))
        if self.model.api_key_env:
            key = os.environ.get(self.model.api_key_env)
            if not key:
                raise BackendError(f"missing API key environment variable {self.model.api_key_env}")
            headers["Authorization"] = f"Bearer {key}"
        request = urllib.request.Request(
            url,
            data=json.dumps(payload).encode("utf-8"),
            headers=headers,
            method="POST",
        )
        started = time.monotonic()
        try:
            with urllib.request.urlopen(request, timeout=self.retry.timeout_seconds) as response:
                value = json.loads(response.read().decode("utf-8"))
        except TimeoutError as error:
            raise BackendTimeout(str(error)) from error
        except urllib.error.HTTPError as error:
            body = error.read().decode("utf-8", errors="replace")
            raise BackendError(f"HTTP {error.code}: {body[:1000]}") from error
        except (urllib.error.URLError, json.JSONDecodeError, KeyError, IndexError, TypeError) as error:
            raise BackendError(str(error)) from error
        choice = value["choices"][0]
        usage = value.get("usage", {})
        required_provider = self.model.extra.get("protocol", {}).get("required_provider")
        actual_provider = value.get("provider")
        if required_provider and actual_provider and actual_provider != required_provider:
            raise BackendError(
                f"provider routing violation: expected {required_provider}, received {actual_provider}"
            )
        return Generation(
            text=choice["message"]["content"] or "",
            finish_reason=choice.get("finish_reason"),
            prompt_tokens=usage.get("prompt_tokens"),
            completion_tokens=usage.get("completion_tokens"),
            latency_seconds=time.monotonic() - started,
            provider_metadata={
                "backend": "openai_compatible",
                "response_id": value.get("id"),
                "routed_model": value.get("model"),
                "provider": value.get("provider"),
                "created": value.get("created"),
                "system_fingerprint": value.get("system_fingerprint"),
                "usage": usage,
                "openrouter_metadata": value.get("openrouter_metadata"),
            },
        )


class StaticBackend(InferenceBackend):
    """Dependency-free deterministic backend for dry runs and tests."""

    def __init__(self, model: ModelConfig, inference: InferenceConfig, retry: RetryConfig) -> None:
        super().__init__(model, inference, retry)
        self.responses = list(model.extra.get("responses", []))
        self.default_response = model.extra.get("response", "")
        self.calls = 0

    def tokenizer(self) -> TokenizerAdapter:
        return CharacterTokenizer()

    def generate(self, messages: Sequence[Message]) -> Generation:
        del messages
        started = time.monotonic()
        if self.calls < len(self.responses):
            text = self.responses[self.calls]
        else:
            text = self.default_response
        self.calls += 1
        return Generation(
            text=text,
            finish_reason="stop",
            prompt_tokens=None,
            completion_tokens=None,
            latency_seconds=time.monotonic() - started,
            provider_metadata={"backend": "static"},
        )


class CharacterTokenizer:
    @property
    def identity(self) -> str:
        return "character-tokenizer-v1"

    def encode(self, text: str, *, add_special_tokens: bool = False) -> list[int]:
        del add_special_tokens
        return [ord(character) for character in text]

    def format_chat(self, messages: Sequence[Message]) -> str:
        return "\n".join(f"{message.role}: {message.content}" for message in messages)


def final_answer_text(raw_text: str, model: ModelConfig) -> str:
    """Return only the answer channel while preserving the raw generation separately."""

    reasoning_format = model.extra.get("reasoning_output")
    if reasoning_format is None:
        return raw_text
    if reasoning_format == "harmony_channels":
        marker = "<|channel|>final<|message|>"
        if marker not in raw_text:
            return ""
        answer = raw_text.rsplit(marker, 1)[1]
        return answer.split("<|end|>", 1)[0].strip()
    if reasoning_format not in {"think_tags", "mistral_think_tags"}:
        raise BackendError(
            f"model {model.name}: unsupported extra.reasoning_output {reasoning_format!r}"
        )
    closing_tag = reasoning_closing_tag(model)
    if closing_tag not in raw_text:
        return ""
    return raw_text.rsplit(closing_tag, 1)[1].strip()


def reasoning_closing_tag(model: ModelConfig) -> str:
    """Return the model family's marker that ends hidden reasoning."""

    if model.extra.get("reasoning_output") == "mistral_think_tags":
        return "[/THINK]"
    return "</think>"


def vllm_runtime_options(model: ModelConfig) -> dict[str, Any]:
    """Return recorded model options plus required runtime compatibility settings."""

    options = dict(model.extra.get("vllm", {}))
    # ExperimentExecutor sends one prompt per generate call.
    options.setdefault("max_num_seqs", 1)
    return options


def vllm_sampling_options(
    model: ModelConfig,
    inference: InferenceConfig,
) -> dict[str, Any]:
    """Return recorded sampling settings, including model-specific calibration settings."""

    options: dict[str, Any] = {
        "max_tokens": inference.max_new_tokens,
        "temperature": inference.temperature,
        "top_p": inference.top_p,
        "seed": inference.seed,
    }
    overrides = model.extra.get("sampling", {})
    if not isinstance(overrides, dict):
        raise BackendError(f"model {model.name}: extra.sampling must be an object")
    allowed = {
        "temperature",
        "top_p",
        "top_k",
        "min_p",
        "presence_penalty",
        "frequency_penalty",
        "repetition_penalty",
        "skip_special_tokens",
    }
    unknown = set(overrides) - allowed
    if unknown:
        names = ", ".join(sorted(unknown))
        raise BackendError(f"model {model.name}: unsupported sampling settings: {names}")
    options.update(overrides)
    return options


def bounded_final_options(
    model: ModelConfig,
    inference: InferenceConfig,
) -> dict[str, Any] | None:
    """Validate an optional two-phase reasoning/final-answer token budget."""

    value = model.extra.get("bounded_final")
    if value is None:
        return None
    if not isinstance(value, dict):
        raise BackendError(f"model {model.name}: extra.bounded_final must be an object")
    allowed = {"mode", "reasoning_tokens", "final_tokens"}
    unknown = set(value) - allowed
    if unknown:
        names = ", ".join(sorted(unknown))
        raise BackendError(f"model {model.name}: unsupported bounded-final settings: {names}")
    mode = value.get("mode")
    reasoning_tokens = value.get("reasoning_tokens")
    final_tokens = value.get("final_tokens")
    if mode not in {"close_think", "followup"}:
        raise BackendError(f"model {model.name}: bounded-final mode must be close_think or followup")
    if not isinstance(reasoning_tokens, int) or not isinstance(final_tokens, int):
        raise BackendError(f"model {model.name}: bounded-final token budgets must be integers")
    if reasoning_tokens < 81 or final_tokens < 81:
        raise BackendError(f"model {model.name}: bounded-final token budgets are too small")
    if reasoning_tokens + final_tokens > inference.max_new_tokens:
        raise BackendError(
            f"model {model.name}: bounded-final budgets exceed max_new_tokens"
        )
    return {
        "mode": mode,
        "reasoning_tokens": reasoning_tokens,
        "final_tokens": final_tokens,
    }


def _phase_sampling(
    sampling: dict[str, Any],
    model: ModelConfig,
    phase: str,
) -> dict[str, Any]:
    bounded = bounded_final_options(model, InferenceConfig(
        max_new_tokens=int(sampling["max_tokens"]),
        temperature=float(sampling["temperature"]),
        top_p=float(sampling["top_p"]),
        seed=int(sampling["seed"]),
    ))
    if bounded is None:
        return sampling
    result = dict(sampling)
    if phase == "reasoning":
        result["max_tokens"] = bounded["reasoning_tokens"]
    elif phase == "final":
        result["max_tokens"] = bounded["final_tokens"]
        result["temperature"] = 0.0
        result["top_p"] = 1.0
    else:
        raise ValueError(f"unknown generation phase {phase!r}")
    return result


def build_backend(
    model: ModelConfig,
    inference: InferenceConfig,
    retry: RetryConfig,
) -> InferenceBackend:
    backend = model.backend
    if backend == "auto":
        backend = "vllm" if importlib.util.find_spec("vllm") is not None else "transformers"
    if backend == "vllm":
        return VLLMBackend(model, inference, retry)
    if backend == "transformers":
        return TransformersBackend(model, inference, retry)
    if backend == "openai_compatible":
        return OpenAICompatibleBackend(model, inference, retry)
    if backend == "static":
        return StaticBackend(model, inference, retry)
    raise BackendError(f"unsupported backend {backend!r}")


def probe_model(model: ModelConfig) -> tuple[bool, str]:
    if model.backend == "static":
        return True, "dependency-free static test backend"
    if model.backend == "openai_compatible":
        if model.api_key_env and not os.environ.get(model.api_key_env):
            return False, f"missing API key environment variable {model.api_key_env}"
        return True, "configured remote or local OpenAI-compatible endpoint"
    model_path = Path(model.resolved_model_id)
    if model_path.exists():
        return True, f"local path exists: {model_path}"
    if importlib.util.find_spec("transformers") is None:
        return False, "transformers is not installed and model_id is not a local path"
    try:
        from transformers import AutoConfig

        AutoConfig.from_pretrained(
            model.resolved_model_id,
            revision=model.revision,
            trust_remote_code=model.trust_remote_code,
            local_files_only=True,
        )
        return True, "model configuration found in the local Hugging Face cache"
    except Exception as error:  # transformers raises several cache/config-specific types
        return False, f"model is not available locally: {error}"


def _local_snapshot_path(model: ModelConfig) -> str:
    direct_path = Path(model.resolved_model_id)
    if direct_path.exists():
        return str(direct_path.resolve())
    try:
        from huggingface_hub import snapshot_download
    except ImportError as error:  # pragma: no cover - optional inference dependency
        raise BackendError("huggingface-hub is required to resolve a cached model snapshot") from error
    try:
        return snapshot_download(
            repo_id=model.resolved_model_id,
            revision=model.revision,
            local_files_only=True,
        )
    except Exception as error:
        raise BackendError(
            f"pinned model snapshot is missing for {model.name}; run 02_download_models.py first"
        ) from error
